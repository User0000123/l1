#ifndef __MODEL_H__
#define __MODEL_H__

#define UNICODE
#define _UNICODE

#include <windows.h>

int WINAPI ModelStart(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd);

#endif